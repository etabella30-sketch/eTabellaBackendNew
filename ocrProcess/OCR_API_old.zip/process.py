import asyncio
from slot_service import SlotService  # Import SlotService
from redis_connection import get_redis_client
import logging
from task import process_individual_task
from datetime import datetime
import os
import pgConnection

def get_date():    
    # Get the current time with the desired timezone
    date = datetime.now()    
    # Extract date components
    year = date.year
    month = date.month
    day = date.day
    return f"{year:04d}-{month:02d}-{day:02d}"


lgfile = get_date()
redis_client = get_redis_client()


log_dir = f'logs/{lgfile}/'
os.makedirs(log_dir, exist_ok=True)
logging.basicConfig(
    filename=f'{log_dir}ocr.log',  # Specify the log file name
    level=logging.INFO,  # Set log level
    format='%(asctime)s [%(levelname)s]: %(message)s'  # Log message format
)



# Configuration
MAX_TASK_SLOTS = 8
MAX_USER_CONCURRENCY = 4

# Initialize slot service
slot_service = SlotService(MAX_TASK_SLOTS, MAX_USER_CONCURRENCY)
redis_client = get_redis_client()         

async def process_user(user_id, task_slots):

    """Process tasks for a user, respecting the allocated task slots."""
    allocated, message = slot_service.allocate_slots(user_id, slots_per_user)
    if not allocated:
        logging.info(f"User {user_id}: {message}")
        print(message)
        return


    try:
        print(f"User {user_id} has been allocated {slots_per_user} task slots.")
        logging.info(f"User {user_id} has been allocated {slots_per_user} task slots.")
        while True:
            task_ids = [
                redis_client.lpop(f"ocr:{user_id}")
                for _ in range(slots_per_user)
            ]

            task_ids = [task_id for task_id in task_ids if task_id]

            if not task_ids:
                print(f"No more tasks for user {user_id}.")
                logging.info(f"No more tasks for user {user_id}.")
                slot_service.release_slots(user_id)
                break

            print(f"User {user_id} is processing tasks: {task_ids}")
            logging.info(f"User {user_id} is processing tasks: {task_ids}")

            tasks = [
                process_individual_task(user_id, task_id.decode('utf-8'))
                for task_id in task_ids
            ]

            await asyncio.gather(*tasks)
            slot_service.release_slots(user_id)
            logging.info(f"Batch of tasks for user {user_id} completed.")
            print(f"Batch of tasks for user {user_id} completed.")
    except Exception as e:
        logging.error(f"Error while processing user {user_id}: {str(e)}", exc_info=True)
        slot_service.release_slots(user_id)

slots_per_user = 1
async def dynamic_task_scheduler():
    """Dynamically allocate task slots to users."""
    active_users = set()
    print(f'Start')

    while True:
        try:
            # Get active users from Redis
            active_users = set(redis_client.lrange("ocr", 0, -1))
            active_users = {user.decode('utf-8') for user in active_users}

            # print(f"active_users {len(active_users)}")
            if not active_users:
                await asyncio.sleep(3)
                continue


            # Cleanup: Remove empty users from the "ocr" list
            for user_id in active_users:
                if redis_client.llen(f"ocr:{user_id}") == 0:
                    print(f"Cleaning up user {user_id} with no tasks.")
                    redis_client.lrem("ocr", 0, user_id)
                    redis_client.delete(f"ocr:{user_id}")
                    active_users.discard(user_id)

            slots_per_user = max(1, slot_service.check_free_slots() // max(1, len(active_users)))
            # print(f'slots_per_user {slots_per_user}')
            tasks = [process_user(user, slots_per_user) for user in active_users]

            asyncio.gather(*tasks)
            await asyncio.sleep(3)


        except Exception as e:
            logging.error(f"Error in dynamic_task_scheduler: {str(e)}", exc_info=True)

async def main():
    try:
        await dynamic_task_scheduler()
    except Exception as e:
        logging.critical(f"Critical error in main: {str(e)}", exc_info=True)

asyncio.run(main())

# if __name__ == "__main__":
#     try:
#     except Exception as e:
#         logging.critical(f"Unhandled exception in the script: {str(e)}", exc_info=True)