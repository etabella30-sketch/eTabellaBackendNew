from kafka import KafkaConsumer
import json
from task import execute_task

# Kafka Listener
def listen_to_kafka():
    """
    Listens to the Kafka topic and executes a task on receiving a message.
    """
    topic = 'upload-response'
    consumer = KafkaConsumer(
        topic,
        bootstrap_servers='192.168.1.3:9092',  # Replace with your Kafka broker address
        group_id='python_listener_group',   # Group ID for this listener
        auto_offset_reset='earliest',       # Start from earliest message
        enable_auto_commit=True,
        value_deserializer=lambda m: json.loads(m.decode('utf-8'))  # Deserialize JSON messages
    )

    print(f"Listening to Kafka topic: {topic}")

    # try:
    #     for msg in consumer:
    #         print(f"Received message: {msg.value}")
    #         if msg.value['event'] == "OCR-JOB":
    #             # execute_task(msg.value['data'])
    #         # execute_task(msg.value)  # Execute the task with the received message
    # except KeyboardInterrupt:
    #     print("Stopping Kafka listener...")
    # finally:
    #     consumer.close()

# if __name__ == "__main__":
print(f"Listening to Kafka")
listen_to_kafka()