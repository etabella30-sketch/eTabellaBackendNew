# Mock utility class for emitting events
class Utility:
    @staticmethod
    def emit(event_data):
        print(f"Emitted event: {event_data}")

# Example usage
utility = Utility()
handler = OCRProgressHandler(utility)

data = "Scanning contents 50% completed---"
resulttype = None
identifier = "task123"
nMasterid = 42
cFilename = "example.pdf"

# Handle the data
resulttype = handler.handle_data(resulttype, data, identifier, nMasterid, cFilename)
