import asyncio
# from flask import Flask, jsonify, request
# from  kafkaListner import listen_to_kafka
import process
from dotenv import load_dotenv


load_dotenv()
# Initialize the Flask application
# app = Flask(__name__)

# @app.route('/')
# async def home():
#     # value = redis_client.get("bull:delete-files:id").decode('utf-8')
#     # print(f"Value from Redis: {value}")
#     # check_redis_queue()
#     return jsonify({"message": "Welcome to the API on port 5014!"})




# # listen_to_kafka()
# # Run the application
# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5014)
