import socketio

# Connect to the Socket.IO server
sio = socketio.Client()

# Define the server address
SERVER_URL = 'http://mipl:5003'  # Replace with your actual server URL and port

# Define connection events
@sio.event
def connect():
    print("Connected to the server!")

@sio.event
def disconnect():
    print("Disconnected from the server!")

# Connect to the server
sio.connect(SERVER_URL)

# Data to emit
data = {'cPath': 'dir/1.pdf'}
emit(message, data){
    sio.emit('send_path', data)  # Replace 'send_path' with your server's event name
}

@sio.on('response_path')  # Replace 'response_path' with the server's event name
def on_response(data):
    print(f"Received response from server: {data}")

print(f"Emitted data: {data}")

# Disconnect after emitting (optional)
sio.disconnect()
